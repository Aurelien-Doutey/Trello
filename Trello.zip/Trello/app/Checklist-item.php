<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Checklist-item extends Model
{
    //
}
