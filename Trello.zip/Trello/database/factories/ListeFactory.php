<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Liste;
use Faker\Generator as Faker;

$factory->define(Liste::class, function (Faker $faker) {
    return [
        //
    ];
});
