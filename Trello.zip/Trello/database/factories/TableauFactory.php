<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Tableau;
use Faker\Generator as Faker;

$factory->define(Tableau::class, function (Faker $faker) {
    return [
        //
    ];
});
