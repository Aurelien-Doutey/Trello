<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Carte;
use Faker\Generator as Faker;

$factory->define(Carte::class, function (Faker $faker) {
    return [
        //
    ];
});
