<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Commentaire;
use Faker\Generator as Faker;

$factory->define(Commentaire::class, function (Faker $faker) {
    return [
        //
    ];
});
